### Tuts+ Course: Top Speed HTML Development with Jade
#### Instructor: Kezz Bracey

If you’re not using Jade, you’re missing out on some of the fastest HTML you’ll ever produce as well as boilerplate templating methods that will slash your development time in half. In “Top Speed HTML Dev with Jade” you’ll learn how to generate full HTML from quick and easy shorthand. You’ll then build on that foundation to create infinitely reusable templates so you never write the same code twice again.


#### Source Files Description:

In this package you'll find all the code seen in the demonstrations throughout the course.

**Available on Tuts+ November 2014**



