## Included External Markdown

By using Jade's language filters directly against the "include" keyword you can write your markdown in a completely separate file and bring it right in for rendering in your templates.

This is cool for a couple of reasons:

* You can keep your MD files nicely organized in neat, content dedicated areas.
* You can use your favorite MD editor for writing, and still get all the advantages of using Jade for everything else.